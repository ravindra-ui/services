#!/bin/bash

sudo yum update -y
echo "Done STEP - 1" >> /home/$USER/task.list
sudo yum install gcc python3-devel python3-setuptools redhat-rpm-config wget -y
echo "Done STEP - 2" >> /home/$USER/task.list
sudo pip3 install --no-cache-dir -U crcmod
echo "Done STEP - 3" >> /home/$USER/task.list
sudo gsutil -m cp gs://ar-sandbox-sample/* /tmp/
echo "Done STEP - 4" >> /home/$USER/task.list
sudo chmod +x /tmp/oracle-setup.sh
sudo chmod +x /tmp/oracle-user.sh
echo "Done - Everything is working now" >> /home/$USER/task.list